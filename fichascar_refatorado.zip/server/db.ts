import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, fichasAIConfig, fichasAIHistory, FichasAIConfig, FichasAIHistory, posts, comments, comparisons, Comment, Comparison } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Fichas AI Database Helpers
 */

export async function getFichasAIConfig(): Promise<FichasAIConfig | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(fichasAIConfig).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updateFichasAIConfig(config: Partial<FichasAIConfig>): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update config: database not available");
    return;
  }

  const existing = await getFichasAIConfig();
  
  if (existing) {
    await db.update(fichasAIConfig).set(config).where(eq(fichasAIConfig.id, existing.id));
  } else {
    await db.insert(fichasAIConfig).values({
      aiProvider: config.aiProvider || "gemini",
      apiKey: config.apiKey || "",
      customPrompt: config.customPrompt || "",
      isActive: config.isActive !== undefined ? config.isActive : true,
    });
  }
}

export async function saveFichaHistory(history: Omit<FichasAIHistory, 'id' | 'createdAt' | 'updatedAt'>): Promise<FichasAIHistory> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(fichasAIHistory).values(history);
  const insertedId = result[0].insertId;
  
  const inserted = await db.select().from(fichasAIHistory).where(eq(fichasAIHistory.id, insertedId as number)).limit(1);
  
  if (inserted.length === 0) {
    throw new Error("Failed to retrieve inserted ficha history");
  }
  
  return inserted[0];
}

export async function updateFichaHistoryStatus(
  id: number,
  status: "pendente" | "sucesso" | "erro",
  errorMessage?: string,
  fichaData?: Record<string, unknown>
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update ficha history: database not available");
    return;
  }

  const updateData: any = {
    status,
    errorMessage: errorMessage || null,
  };

  if (fichaData) {
    updateData.fichaData = JSON.stringify(fichaData);
  }

  await db.update(fichasAIHistory).set(updateData).where(eq(fichasAIHistory.id, id));
}

export async function getFichaHistory(id: number): Promise<FichasAIHistory | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(fichasAIHistory).where(eq(fichasAIHistory.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getUserFichaHistory(userId: number): Promise<FichasAIHistory[]> {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(fichasAIHistory).where(eq(fichasAIHistory.userId, userId));
}

/**
 * Posts Database Helpers
 */

export async function createPost(post: Omit<typeof posts.$inferInsert, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(posts).values(post);
  const insertedId = result[0].insertId;
  
  const inserted = await db.select().from(posts).where(eq(posts.id, insertedId as number)).limit(1);
  
  if (inserted.length === 0) {
    throw new Error("Failed to retrieve inserted post");
  }
  
  return inserted[0];
}

export async function getPostBySlug(slug: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getPublishedPosts(limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(posts).where(eq(posts.published, true)).limit(limit).offset(offset);
}

export async function getAllPosts(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(posts).limit(limit).offset(offset);
}

export async function updatePost(id: number, data: Partial<typeof posts.$inferInsert>) {
  const db = await getDb();
  if (!db) return null;

  await db.update(posts).set(data).where(eq(posts.id, id));
  
  const result = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function deletePost(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.delete(posts).where(eq(posts.id, id));
  return true;
}

export async function searchPosts(query: string) {
  const db = await getDb();
  if (!db) return [];

  // Busca simples por marca, modelo ou título
  const searchPattern = `%${query}%`;
  return await db.select().from(posts).where(
    eq(posts.published, true)
  ).limit(20);
}

/**
 * Comments Database Helpers
 */

export async function createComment(comment: Omit<Comment, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(comments).values(comment);
  const insertedId = result[0].insertId;
  
  const inserted = await db.select().from(comments).where(eq(comments.id, insertedId as number)).limit(1);
  
  if (inserted.length === 0) {
    throw new Error("Failed to retrieve inserted comment");
  }
  
  return inserted[0];
}

export async function getPostComments(postId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(comments).where(eq(comments.postId, postId));
}

export async function getCommentById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(comments).where(eq(comments.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

/**
 * Comparisons Database Helpers
 */

export async function createComparison(comparison: Omit<Comparison, 'id' | 'createdAt' | 'updatedAt'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(comparisons).values(comparison);
  const insertedId = result[0].insertId;
  
  const inserted = await db.select().from(comparisons).where(eq(comparisons.id, insertedId as number)).limit(1);
  
  if (inserted.length === 0) {
    throw new Error("Failed to retrieve inserted comparison");
  }
  
  return inserted[0];
}

export async function getUserComparisons(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(comparisons).where(eq(comparisons.userId, userId));
}

export async function getComparisonById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(comparisons).where(eq(comparisons.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}
