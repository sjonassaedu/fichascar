import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Share2, Download } from "lucide-react";

export default function FichaDetail() {
  const [, navigate] = useLocation();

  // Dados de exemplo - em produção viriam da API
  const ficha = {
    id: 1,
    title: "Toyota Yaris Versão 1 (2020)",
    marca: "Toyota",
    modelo: "Yaris",
    ano: 2020,
    versao: "1.2 Automático",
    // Motorização
    motor: "1.2L 16V VVT-i",
    tipo: "Gasolina",
    cilindradas: "1197 cc",
    cilindros: "4",
    valvulas: "16",
    potencia: "87 cv @ 6000 rpm",
    torque: "12,3 kgf.m @ 4400 rpm",
    combustivel: "Gasolina",
    transmissao: "Automática",
    cambio: "CVT",
    // Desempenho
    velocidadeMaxima: "180 km/h",
    aceleracao0100: "10,5 s",
    consumoUrbano: "12,8 km/l",
    consumoRodoviario: "15,2 km/l",
    consumoCombinado: "13,8 km/l",
    emissaoCO2: "165 g/km",
    // Dimensões
    comprimento: "3.945 mm",
    largura: "1.695 mm",
    altura: "1.500 mm",
    entreEixos: "2.510 mm",
    peso: "1.050 kg",
    portaMalas: "268 litros",
    tanque: "42 litros",
    // Mecânica
    direcao: "Elétrica",
    tracao: "Dianteira",
    suspensaoDianteira: "Independente com molas helicoidais",
    suspensaoTraseira: "Barra de torção",
    freioDianteiro: "Disco ventilado",
    freioTraseiro: "Tambor",
    rodas: "14 polegadas",
    pneus: "175/70 R14",
    // Capacidades
    portas: "4",
    lugares: "5",
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate("/blog")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">FichasCAR</h1>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4 mr-2" />
              Compartilhar
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-2">{ficha.title}</h1>
          <p className="text-blue-100 mb-8">Ficha técnica completa do veículo</p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-blue-500 bg-opacity-50 rounded-lg p-4">
              <p className="text-blue-100 text-sm">ANO</p>
              <p className="text-2xl font-bold">{ficha.ano}</p>
            </div>
            <div className="bg-blue-500 bg-opacity-50 rounded-lg p-4">
              <p className="text-blue-100 text-sm">POTÊNCIA</p>
              <p className="text-2xl font-bold">{ficha.potencia}</p>
            </div>
            <div className="bg-blue-500 bg-opacity-50 rounded-lg p-4">
              <p className="text-blue-100 text-sm">VELOCIDADE</p>
              <p className="text-2xl font-bold">{ficha.velocidadeMaxima}</p>
            </div>
            <div className="bg-blue-500 bg-opacity-50 rounded-lg p-4">
              <p className="text-blue-100 text-sm">0-100 KM/H</p>
              <p className="text-2xl font-bold">{ficha.aceleracao0100}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <Tabs defaultValue="motorization" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="motorization">⚙️ Motor</TabsTrigger>
            <TabsTrigger value="performance">🏁 Desempenho</TabsTrigger>
            <TabsTrigger value="dimensions">📐 Dimensões</TabsTrigger>
            <TabsTrigger value="mechanics">🔧 Mecânica</TabsTrigger>
            <TabsTrigger value="capacities">👥 Capacidades</TabsTrigger>
          </TabsList>

          {/* Motorização */}
          <TabsContent value="motorization">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Motorização</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Motor</p>
                    <p className="font-semibold text-gray-900">{ficha.motor}</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Tipo</p>
                    <p className="font-semibold text-gray-900">{ficha.tipo}</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Cilindradas</p>
                    <p className="font-semibold text-gray-900">{ficha.cilindradas}</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Cilindros</p>
                    <p className="font-semibold text-gray-900">{ficha.cilindros}</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Válvulas</p>
                    <p className="font-semibold text-gray-900">{ficha.valvulas}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Potência e Torque</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-orange-500 pl-4">
                    <p className="text-gray-600 text-sm">Potência</p>
                    <p className="font-semibold text-gray-900">{ficha.potencia}</p>
                  </div>
                  <div className="border-l-4 border-orange-500 pl-4">
                    <p className="text-gray-600 text-sm">Torque</p>
                    <p className="font-semibold text-gray-900">{ficha.torque}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Transmissão</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-green-500 pl-4">
                    <p className="text-gray-600 text-sm">Combustível</p>
                    <p className="font-semibold text-gray-900">{ficha.combustivel}</p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4">
                    <p className="text-gray-600 text-sm">Transmissão</p>
                    <p className="font-semibold text-gray-900">{ficha.transmissao}</p>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4">
                    <p className="text-gray-600 text-sm">Câmbio</p>
                    <p className="font-semibold text-gray-900">{ficha.cambio}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Desempenho */}
          <TabsContent value="performance">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Velocidade e Aceleração</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-red-500 pl-4">
                    <p className="text-gray-600 text-sm">Velocidade Máxima</p>
                    <p className="font-semibold text-gray-900">{ficha.velocidadeMaxima}</p>
                  </div>
                  <div className="border-l-4 border-red-500 pl-4">
                    <p className="text-gray-600 text-sm">Aceleração 0-100 km/h</p>
                    <p className="font-semibold text-gray-900">{ficha.aceleracao0100}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Consumo de Combustível</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-yellow-500 pl-4">
                    <p className="text-gray-600 text-sm">Consumo Urbano</p>
                    <p className="font-semibold text-gray-900">{ficha.consumoUrbano}</p>
                  </div>
                  <div className="border-l-4 border-yellow-500 pl-4">
                    <p className="text-gray-600 text-sm">Consumo Rodoviário</p>
                    <p className="font-semibold text-gray-900">{ficha.consumoRodoviario}</p>
                  </div>
                  <div className="border-l-4 border-yellow-500 pl-4">
                    <p className="text-gray-600 text-sm">Consumo Combinado</p>
                    <p className="font-semibold text-gray-900">{ficha.consumoCombinado}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Emissões</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-green-600 pl-4">
                    <p className="text-gray-600 text-sm">Emissão CO2</p>
                    <p className="font-semibold text-gray-900">{ficha.emissaoCO2}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Dimensões */}
          <TabsContent value="dimensions">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dimensões Externas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-purple-500 pl-4">
                    <p className="text-gray-600 text-sm">Comprimento</p>
                    <p className="font-semibold text-gray-900">{ficha.comprimento}</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <p className="text-gray-600 text-sm">Largura</p>
                    <p className="font-semibold text-gray-900">{ficha.largura}</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <p className="text-gray-600 text-sm">Altura</p>
                    <p className="font-semibold text-gray-900">{ficha.altura}</p>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4">
                    <p className="text-gray-600 text-sm">Entre-eixos</p>
                    <p className="font-semibold text-gray-900">{ficha.entreEixos}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Peso e Capacidade</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-indigo-500 pl-4">
                    <p className="text-gray-600 text-sm">Peso</p>
                    <p className="font-semibold text-gray-900">{ficha.peso}</p>
                  </div>
                  <div className="border-l-4 border-indigo-500 pl-4">
                    <p className="text-gray-600 text-sm">Porta-malas</p>
                    <p className="font-semibold text-gray-900">{ficha.portaMalas}</p>
                  </div>
                  <div className="border-l-4 border-indigo-500 pl-4">
                    <p className="text-gray-600 text-sm">Tanque de Combustível</p>
                    <p className="font-semibold text-gray-900">{ficha.tanque}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Mecânica */}
          <TabsContent value="mechanics">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Direção e Tração</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-cyan-500 pl-4">
                    <p className="text-gray-600 text-sm">Direção</p>
                    <p className="font-semibold text-gray-900">{ficha.direcao}</p>
                  </div>
                  <div className="border-l-4 border-cyan-500 pl-4">
                    <p className="text-gray-600 text-sm">Tração</p>
                    <p className="font-semibold text-gray-900">{ficha.tracao}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Suspensão</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-pink-500 pl-4">
                    <p className="text-gray-600 text-sm">Suspensão Dianteira</p>
                    <p className="font-semibold text-gray-900">{ficha.suspensaoDianteira}</p>
                  </div>
                  <div className="border-l-4 border-pink-500 pl-4">
                    <p className="text-gray-600 text-sm">Suspensão Traseira</p>
                    <p className="font-semibold text-gray-900">{ficha.suspensaoTraseira}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Freios e Rodas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-rose-500 pl-4">
                    <p className="text-gray-600 text-sm">Freio Dianteiro</p>
                    <p className="font-semibold text-gray-900">{ficha.freioDianteiro}</p>
                  </div>
                  <div className="border-l-4 border-rose-500 pl-4">
                    <p className="text-gray-600 text-sm">Freio Traseiro</p>
                    <p className="font-semibold text-gray-900">{ficha.freioTraseiro}</p>
                  </div>
                  <div className="border-l-4 border-rose-500 pl-4">
                    <p className="text-gray-600 text-sm">Rodas</p>
                    <p className="font-semibold text-gray-900">{ficha.rodas}</p>
                  </div>
                  <div className="border-l-4 border-rose-500 pl-4">
                    <p className="text-gray-600 text-sm">Pneus</p>
                    <p className="font-semibold text-gray-900">{ficha.pneus}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Capacidades */}
          <TabsContent value="capacities">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Capacidades</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Portas</p>
                    <p className="font-semibold text-gray-900">{ficha.portas}</p>
                  </div>
                  <div className="border-l-4 border-blue-500 pl-4">
                    <p className="text-gray-600 text-sm">Lugares</p>
                    <p className="font-semibold text-gray-900">{ficha.lugares}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Comentários */}
        <Card className="mt-12">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">💬 Comentários e Avaliações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
              <p className="text-gray-700 mb-3">Faça login para comentar e avaliar este veículo</p>
              <Button variant="outline">Fazer Login</Button>
            </div>
            <div className="bg-gray-50 rounded-lg p-4 text-center text-gray-500">
              Nenhum comentário ainda. Seja o primeiro a comentar!
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8 text-center text-gray-400">
          <p>&copy; 2024 FichasCAR. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
