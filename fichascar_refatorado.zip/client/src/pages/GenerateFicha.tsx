import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, AlertCircle, CheckCircle, Copy } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface FichaData {
  motor: string;
  tipo: string;
  cilindradas: string;
  potencia: string;
  torque: string;
  combustivel: string;
  transmissao: string;
  velocidadeMaxima: string;
  aceleracao: string;
  consumoUrbano: string;
  consumoRodoviario: string;
  comprimento: string;
  largura: string;
  altura: string;
  entreEixos: string;
  peso: string;
  portaMalas: string;
  tanque: string;
  direcao: string;
  tracao: string;
  suspensaoDianteira: string;
  suspensaoTraseira: string;
  freioDianteiro: string;
  freioTraseiro: string;
  rodas: string;
  pneus: string;
  portas: string;
  lugares: string;
}

export default function GenerateFicha() {
  const { user, isAuthenticated } = useAuth();
  const [formData, setFormData] = useState({
    marca: "",
    modelo: "",
    ano: new Date().getFullYear(),
    versao: "",
  });

  const [generatedFicha, setGeneratedFicha] = useState<FichaData | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  // Mutation para gerar ficha
  const generateFichaMutation = trpc.fichasAI.generateFicha.useMutation({
    onSuccess: (data) => {
      setGeneratedFicha(data.ficha);
      setSuccessMessage("Ficha gerada com sucesso!");
      setErrorMessage("");
      setTimeout(() => setSuccessMessage(""), 3000);
    },
    onError: (error) => {
      setErrorMessage(error.message || "Erro ao gerar ficha");
      setGeneratedFicha(null);
      setSuccessMessage("");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.marca || !formData.modelo || !formData.versao) {
      setErrorMessage("Por favor, preencha todos os campos obrigatórios");
      return;
    }

    try {
      await generateFichaMutation.mutateAsync({
        marca: formData.marca,
        modelo: formData.modelo,
        ano: formData.ano,
        versao: formData.versao,
      });
    } catch (error) {
      console.error("Erro ao gerar ficha:", error);
    }
  };

  const handleCopyToClipboard = () => {
    if (generatedFicha) {
      const text = JSON.stringify(generatedFicha, null, 2);
      navigator.clipboard.writeText(text);
      setSuccessMessage("Dados copiados para a área de transferência!");
      setTimeout(() => setSuccessMessage(""), 2000);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">Você precisa estar autenticado para acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulário */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Gerar Ficha Técnica</CardTitle>
                <CardDescription>Preencha os dados do veículo</CardDescription>
              </CardHeader>
              <CardContent>
                {errorMessage && (
                  <Alert className="mb-4 bg-red-50 border-red-200">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">{errorMessage}</AlertDescription>
                  </Alert>
                )}

                {successMessage && (
                  <Alert className="mb-4 bg-green-50 border-green-200">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">{successMessage}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Marca */}
                  <div className="space-y-2">
                    <Label htmlFor="marca">Marca *</Label>
                    <Input
                      id="marca"
                      placeholder="Ex: Toyota"
                      value={formData.marca}
                      onChange={(e) => setFormData({ ...formData, marca: e.target.value })}
                      disabled={generateFichaMutation.isPending}
                    />
                  </div>

                  {/* Modelo */}
                  <div className="space-y-2">
                    <Label htmlFor="modelo">Modelo *</Label>
                    <Input
                      id="modelo"
                      placeholder="Ex: Yaris"
                      value={formData.modelo}
                      onChange={(e) => setFormData({ ...formData, modelo: e.target.value })}
                      disabled={generateFichaMutation.isPending}
                    />
                  </div>

                  {/* Ano */}
                  <div className="space-y-2">
                    <Label htmlFor="ano">Ano</Label>
                    <Input
                      id="ano"
                      type="number"
                      placeholder="Ex: 2020"
                      value={formData.ano}
                      onChange={(e) => setFormData({ ...formData, ano: parseInt(e.target.value) })}
                      disabled={generateFichaMutation.isPending}
                    />
                  </div>

                  {/* Versão */}
                  <div className="space-y-2">
                    <Label htmlFor="versao">Versão *</Label>
                    <Input
                      id="versao"
                      placeholder="Ex: 1.2 Automático"
                      value={formData.versao}
                      onChange={(e) => setFormData({ ...formData, versao: e.target.value })}
                      disabled={generateFichaMutation.isPending}
                    />
                  </div>

                  {/* Botão de Gerar */}
                  <Button
                    type="submit"
                    disabled={generateFichaMutation.isPending}
                    className="w-full flex items-center justify-center gap-2"
                  >
                    {generateFichaMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Gerando...
                      </>
                    ) : (
                      "Gerar Ficha"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Resultado */}
          {generatedFicha && (
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Ficha Técnica Gerada</CardTitle>
                    <CardDescription>
                      {formData.marca} {formData.modelo} ({formData.ano})
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyToClipboard}
                    className="flex items-center gap-2"
                  >
                    <Copy className="h-4 w-4" />
                    Copiar
                  </Button>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="motorization" className="w-full">
                    <TabsList className="grid w-full grid-cols-5">
                      <TabsTrigger value="motorization">⚙️</TabsTrigger>
                      <TabsTrigger value="performance">🏁</TabsTrigger>
                      <TabsTrigger value="dimensions">📐</TabsTrigger>
                      <TabsTrigger value="mechanics">🔧</TabsTrigger>
                      <TabsTrigger value="capacities">👥</TabsTrigger>
                    </TabsList>

                    {/* Motorização */}
                    <TabsContent value="motorization" className="space-y-3">
                      <h3 className="font-semibold">Motorização</h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-gray-600">Motor</p>
                          <p className="font-medium">{generatedFicha.motor}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Tipo</p>
                          <p className="font-medium">{generatedFicha.tipo}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Cilindradas</p>
                          <p className="font-medium">{generatedFicha.cilindradas}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Potência</p>
                          <p className="font-medium">{generatedFicha.potencia}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Torque</p>
                          <p className="font-medium">{generatedFicha.torque}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Combustível</p>
                          <p className="font-medium">{generatedFicha.combustivel}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-gray-600">Transmissão</p>
                          <p className="font-medium">{generatedFicha.transmissao}</p>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Desempenho */}
                    <TabsContent value="performance" className="space-y-3">
                      <h3 className="font-semibold">Desempenho</h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-gray-600">Velocidade Máxima</p>
                          <p className="font-medium">{generatedFicha.velocidadeMaxima}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Aceleração 0-100</p>
                          <p className="font-medium">{generatedFicha.aceleracao}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Consumo Urbano</p>
                          <p className="font-medium">{generatedFicha.consumoUrbano}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Consumo Rodoviário</p>
                          <p className="font-medium">{generatedFicha.consumoRodoviario}</p>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Dimensões */}
                    <TabsContent value="dimensions" className="space-y-3">
                      <h3 className="font-semibold">Dimensões</h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-gray-600">Comprimento</p>
                          <p className="font-medium">{generatedFicha.comprimento}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Largura</p>
                          <p className="font-medium">{generatedFicha.largura}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Altura</p>
                          <p className="font-medium">{generatedFicha.altura}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Entre-eixos</p>
                          <p className="font-medium">{generatedFicha.entreEixos}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Peso</p>
                          <p className="font-medium">{generatedFicha.peso}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Porta-malas</p>
                          <p className="font-medium">{generatedFicha.portaMalas}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-gray-600">Tanque</p>
                          <p className="font-medium">{generatedFicha.tanque}</p>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Mecânica */}
                    <TabsContent value="mechanics" className="space-y-3">
                      <h3 className="font-semibold">Mecânica e Chassis</h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-gray-600">Direção</p>
                          <p className="font-medium">{generatedFicha.direcao}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Tração</p>
                          <p className="font-medium">{generatedFicha.tracao}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Suspensão Dianteira</p>
                          <p className="font-medium">{generatedFicha.suspensaoDianteira}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Suspensão Traseira</p>
                          <p className="font-medium">{generatedFicha.suspensaoTraseira}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Freio Dianteiro</p>
                          <p className="font-medium">{generatedFicha.freioDianteiro}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Freio Traseiro</p>
                          <p className="font-medium">{generatedFicha.freioTraseiro}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Rodas</p>
                          <p className="font-medium">{generatedFicha.rodas}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Pneus</p>
                          <p className="font-medium">{generatedFicha.pneus}</p>
                        </div>
                      </div>
                    </TabsContent>

                    {/* Capacidades */}
                    <TabsContent value="capacities" className="space-y-3">
                      <h3 className="font-semibold">Capacidades</h3>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <p className="text-gray-600">Portas</p>
                          <p className="font-medium">{generatedFicha.portas}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Lugares</p>
                          <p className="font-medium">{generatedFicha.lugares}</p>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
