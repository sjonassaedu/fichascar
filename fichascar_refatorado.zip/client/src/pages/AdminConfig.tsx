import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { Loader2, AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function AdminConfig() {
  const { user, isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    aiProvider: "gemini" as "gemini" | "gpt" | "claude",
    apiKey: "",
    customPrompt: "",
  });

  // Buscar configuração atual
  const { data: config, isLoading: isLoadingConfig } = trpc.fichasAI.getConfig.useQuery();

  useEffect(() => {
    if (config) {
      setFormData({
        aiProvider: (config.aiProvider as "gemini" | "gpt" | "claude") || "gemini",
        apiKey: config.apiKey || "",
        customPrompt: config.customPrompt || "",
      });
    }
  }, [config]);

  // Mutation para atualizar configuração
  const updateConfigMutation = trpc.fichasAI.updateConfig.useMutation({
    onSuccess: () => {
      setSuccessMessage("Configuração atualizada com sucesso!");
      setErrorMessage("");
      setTimeout(() => setSuccessMessage(""), 3000);
    },
    onError: (error) => {
      setErrorMessage(error.message || "Erro ao atualizar configuração");
      setSuccessMessage("");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await updateConfigMutation.mutateAsync({
        aiProvider: formData.aiProvider,
        apiKey: formData.apiKey || undefined,
        customPrompt: formData.customPrompt || undefined,
      });
    } catch (error) {
      console.error("Erro ao atualizar configuração:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">Você precisa estar autenticado para acessar esta página.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso Negado</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">Apenas administradores podem acessar as configurações.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Configuração - Fichas AI</CardTitle>
            <CardDescription>Configure a integração com APIs de IA para gerar fichas técnicas de veículos</CardDescription>
          </CardHeader>
          <CardContent>
            {successMessage && (
              <Alert className="mb-4 bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">{successMessage}</AlertDescription>
              </Alert>
            )}

            {errorMessage && (
              <Alert className="mb-4 bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">{errorMessage}</AlertDescription>
              </Alert>
            )}

            {isLoadingConfig ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Seletor de Provider */}
                <div className="space-y-2">
                  <Label htmlFor="aiProvider">Provedor de IA</Label>
                  <Select
                    value={formData.aiProvider}
                    onValueChange={(value) =>
                      setFormData({ ...formData, aiProvider: value as "gemini" | "gpt" | "claude" })
                    }
                  >
                    <SelectTrigger id="aiProvider">
                      <SelectValue placeholder="Selecione um provedor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gemini">Google Gemini</SelectItem>
                      <SelectItem value="gpt">OpenAI GPT</SelectItem>
                      <SelectItem value="claude">Anthropic Claude</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-gray-500">Escolha qual API de IA será utilizada para gerar as fichas</p>
                </div>

                {/* Campo de API Key */}
                <div className="space-y-2">
                  <Label htmlFor="apiKey">Chave de API</Label>
                  <Input
                    id="apiKey"
                    type="password"
                    placeholder="Insira sua chave de API"
                    value={formData.apiKey}
                    onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                  />
                  <p className="text-xs text-gray-500">
                    A chave será armazenada de forma segura e usada apenas para gerar fichas
                  </p>
                </div>

                {/* Campo de Prompt Customizado */}
                <div className="space-y-2">
                  <Label htmlFor="customPrompt">Prompt Customizado</Label>
                  <Textarea
                    id="customPrompt"
                    placeholder="Digite o prompt que deseja usar para gerar fichas..."
                    value={formData.customPrompt}
                    onChange={(e) => setFormData({ ...formData, customPrompt: e.target.value })}
                    rows={6}
                    className="font-mono text-sm"
                  />
                  <p className="text-xs text-gray-500">
                    Use as variáveis {"{marca}"}, {"{modelo}"}, {"{ano}"} e {"{versao}"} no seu prompt. A IA
                    substituirá essas variáveis pelos valores inseridos.
                  </p>
                </div>

                {/* Botão de Salvar */}
                <div className="flex gap-2">
                  <Button
                    type="submit"
                    disabled={isLoading || updateConfigMutation.isPending}
                    className="flex items-center gap-2"
                  >
                    {isLoading || updateConfigMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      "Salvar Configuração"
                    )}
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>

        {/* Informações de Ajuda */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-base">Informações de Ajuda</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div>
              <h4 className="font-semibold mb-2">Variáveis do Prompt</h4>
              <ul className="list-disc list-inside space-y-1 text-gray-600">
                <li>
                  <code className="bg-gray-100 px-2 py-1 rounded">{"{marca}"}</code> - Marca do veículo
                </li>
                <li>
                  <code className="bg-gray-100 px-2 py-1 rounded">{"{modelo}"}</code> - Modelo do veículo
                </li>
                <li>
                  <code className="bg-gray-100 px-2 py-1 rounded">{"{ano}"}</code> - Ano do veículo
                </li>
                <li>
                  <code className="bg-gray-100 px-2 py-1 rounded">{"{versao}"}</code> - Versão do veículo
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Exemplo de Prompt</h4>
              <pre className="bg-gray-100 p-3 rounded text-xs overflow-auto">
                {`Busque informações técnicas completas para o veículo:
Marca: {marca}
Modelo: {modelo}
Ano: {ano}
Versão: {versao}

Retorne um JSON com todos os campos técnicos.`}
              </pre>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
