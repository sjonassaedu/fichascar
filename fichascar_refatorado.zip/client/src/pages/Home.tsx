import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { Zap, Settings, FileText } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {APP_LOGO && <img src={APP_LOGO} alt={APP_TITLE} className="h-10 w-10" />}
            <h1 className="text-2xl font-bold text-gray-900">{APP_TITLE}</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-gray-600">Olá, {user?.name || "Usuário"}</span>
                <Button variant="outline" onClick={() => logout()}>
                  Sair
                </Button>
              </>
            ) : (
              <Button onClick={() => (window.location.href = getLoginUrl())}>Entrar</Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        {!isAuthenticated ? (
          // Não autenticado
          <div className="text-center py-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Bem-vindo ao Fichas AI</h2>
            <p className="text-xl text-gray-600 mb-8">
              Gere fichas técnicas de veículos automaticamente com inteligência artificial
            </p>
            <Button size="lg" onClick={() => (window.location.href = getLoginUrl())}>
              Entrar para Começar
            </Button>
          </div>
        ) : (
          // Autenticado
          <div>
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Bem-vindo, {user?.name}!</h2>
              <p className="text-gray-600">Escolha uma opção abaixo para começar</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Card: Gerar Ficha */}
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate("/gerar-ficha")}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <Zap className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle>Gerar Ficha Técnica</CardTitle>
                      <CardDescription>Crie uma nova ficha de veículo</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Preencha os dados do veículo (marca, modelo, ano e versão) e a IA gerará uma ficha técnica completa
                    com todos os dados técnicos.
                  </p>
                </CardContent>
              </Card>

              {/* Card: Configurações (apenas para admin) */}
              {user?.role === "admin" && (
                <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => navigate("/admin/config")}>
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 p-3 rounded-lg">
                        <Settings className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <CardTitle>Configurações</CardTitle>
                        <CardDescription>Configure a integração com IA</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">
                      Configure qual API de IA será utilizada (Gemini, GPT, Claude) e customize o prompt para gerar as
                      fichas.
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Card: Histórico */}
              <Card className="hover:shadow-lg transition-shadow cursor-pointer opacity-50 cursor-not-allowed">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="bg-green-100 p-3 rounded-lg">
                      <FileText className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <CardTitle>Histórico</CardTitle>
                      <CardDescription>Fichas geradas (em breve)</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">Visualize o histórico de todas as fichas que você gerou.</p>
                </CardContent>
              </Card>
            </div>

            {/* Informações */}
            <div className="mt-12 bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Como Funciona</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">1</div>
                  <h4 className="font-semibold text-gray-900 mb-2">Preencha os Dados</h4>
                  <p className="text-sm text-gray-600">
                    Insira a marca, modelo, ano e versão do veículo que deseja pesquisar.
                  </p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">2</div>
                  <h4 className="font-semibold text-gray-900 mb-2">IA Processa</h4>
                  <p className="text-sm text-gray-600">
                    A inteligência artificial busca e processa os dados técnicos do veículo.
                  </p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">3</div>
                  <h4 className="font-semibold text-gray-900 mb-2">Receba a Ficha</h4>
                  <p className="text-sm text-gray-600">
                    Obtenha uma ficha técnica completa com todos os dados do veículo.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8 text-center text-gray-400">
          <p>&copy; 2024 Fichas AI. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
