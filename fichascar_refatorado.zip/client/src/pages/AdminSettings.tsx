import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Key, BarChart3, DollarSign } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

export default function AdminSettings() {
  const [isSaving, setIsSaving] = useState(false);

  // Estados para cada seção
  const [iaProvider, setIaProvider] = useState("gemini");
  const [iaApiKey, setIaApiKey] = useState("");
  const [customPrompt, setCustomPrompt] = useState("");

  const [gaTrackingId, setGaTrackingId] = useState("");
  const [adsenseClientId, setAdsenseClientId] = useState("");
  const [adsenseSlots, setAdsenseSlots] = useState({
    headerBanner: "",
    sidebarRectangle: "",
    footerBanner: "",
    fichaDetail: "",
  });

  const handleSaveSettings = async () => {
    setIsSaving(true);
    try {
      // Aqui você chamaria a API para salvar as configurações
      // await trpc.admin.saveSettings.useMutation({...})
      toast.success("Configurações salvas com sucesso!");
    } catch (error) {
      toast.error("Erro ao salvar configurações");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 flex items-center gap-3">
            <Settings className="h-10 w-10 text-blue-600" />
            Configurações do Site
          </h1>
          <p className="text-gray-600 mt-2">Gerencie todas as configurações em um único lugar</p>
        </div>

        <Tabs defaultValue="ia" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="ia" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              IA e Geração
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="monetizacao" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Monetização
            </TabsTrigger>
          </TabsList>

          {/* Aba 1: Configurações de IA */}
          <TabsContent value="ia">
            <Card>
              <CardHeader>
                <CardTitle>Configuração de IA para Geração de Fichas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">Provedor de IA</label>
                  <select
                    value={iaProvider}
                    onChange={(e) => setIaProvider(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="gemini">Google Gemini</option>
                    <option value="gpt">OpenAI GPT</option>
                    <option value="claude">Anthropic Claude</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Chave de API</label>
                  <Input
                    type="password"
                    placeholder="Cole sua chave de API aqui"
                    value={iaApiKey}
                    onChange={(e) => setIaApiKey(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Sua chave será criptografada e armazenada com segurança
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Prompt Customizado</label>
                  <Textarea
                    placeholder="Defina o prompt que a IA usará para gerar as fichas técnicas..."
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    className="w-full min-h-32"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Use {'{marca}'}, {'{modelo}'}, {'{ano}'}, {'{versao}'} como variáveis
                  </p>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900">
                    <strong>Dica:</strong> Use um prompt descritivo para obter melhores resultados. Exemplo: &quot;Gere uma ficha técnica completa e detalhada para o [marca] [modelo] [ano] versão [versao], incluindo todas as especificações técnicas...&quot;
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba 2: Google Analytics */}
          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle>Google Analytics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">ID de Rastreamento (GA4)</label>
                  <Input
                    placeholder="G-XXXXXXXXXX"
                    value={gaTrackingId}
                    onChange={(e) => setGaTrackingId(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Encontre seu ID em: Google Analytics → Admin → Propriedades → ID da Propriedade
                  </p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <p className="text-sm text-green-900 mb-2">
                    <strong>✓ Benefícios do Google Analytics:</strong>
                  </p>
                  <ul className="text-sm text-green-800 space-y-1 ml-4">
                    <li>• Rastreie visitantes e comportamento dos usuários</li>
                    <li>• Analise quais fichas são mais populares</li>
                    <li>• Monitore taxa de rejeição e tempo de permanência</li>
                    <li>• Identifique oportunidades de melhoria</li>
                    <li>• Dados essenciais para otimizar AdSense</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Como Obter seu ID de Rastreamento:</h3>
                  <ol className="text-sm space-y-2 ml-4 list-decimal">
                    <li>Acesse <a href="https://analytics.google.com" target="_blank" className="text-blue-600 hover:underline">Google Analytics</a></li>
                    <li>Clique em "Admin" (ícone de engrenagem)</li>
                    <li>Selecione sua propriedade</li>
                    <li>Em "Propriedades", clique em "Detalhes da Propriedade"</li>
                    <li>Copie o "ID da Propriedade" (começa com G-)</li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba 3: Google AdSense */}
          <TabsContent value="monetizacao">
            <Card>
              <CardHeader>
                <CardTitle>Google AdSense - Monetização</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">ID do Publicador (Client ID)</label>
                  <Input
                    placeholder="ca-pub-xxxxxxxxxxxxxxxx"
                    value={adsenseClientId}
                    onChange={(e) => setAdsenseClientId(e.target.value)}
                    className="w-full"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Encontre em: AdSense → Configurações → Conta
                  </p>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Slots de Anúncios</h3>

                  <div>
                    <label className="block text-sm font-medium mb-1">Banner no Topo</label>
                    <Input
                      placeholder="Número do slot"
                      value={adsenseSlots.headerBanner}
                      onChange={(e) =>
                        setAdsenseSlots({ ...adsenseSlots, headerBanner: e.target.value })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Retângulo na Lateral</label>
                    <Input
                      placeholder="Número do slot"
                      value={adsenseSlots.sidebarRectangle}
                      onChange={(e) =>
                        setAdsenseSlots({ ...adsenseSlots, sidebarRectangle: e.target.value })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Banner no Rodapé</label>
                    <Input
                      placeholder="Número do slot"
                      value={adsenseSlots.footerBanner}
                      onChange={(e) =>
                        setAdsenseSlots({ ...adsenseSlots, footerBanner: e.target.value })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Anúncio na Ficha Técnica</label>
                    <Input
                      placeholder="Número do slot"
                      value={adsenseSlots.fichaDetail}
                      onChange={(e) =>
                        setAdsenseSlots({ ...adsenseSlots, fichaDetail: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <p className="text-sm text-yellow-900 mb-2">
                    <strong>⚠️ Importante para AdSense:</strong>
                  </p>
                  <ul className="text-sm text-yellow-800 space-y-1 ml-4">
                    <li>• Conteúdo original e de qualidade (fichas técnicas detalhadas)</li>
                    <li>• Mínimo de 10-15 fichas publicadas antes de aplicar</li>
                    <li>• Site deve estar indexado no Google</li>
                    <li>• Respeite as políticas de AdSense (sem conteúdo proibido)</li>
                    <li>• Tempo de aprovação: 24-48 horas</li>
                  </ul>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900 mb-2">
                    <strong>💰 Dicas para Maximizar Ganhos:</strong>
                  </p>
                  <ul className="text-sm text-blue-800 space-y-1 ml-4">
                    <li>• Coloque anúncios acima da dobra (primeiros 600px)</li>
                    <li>• Use múltiplos formatos (banner, retângulo, responsivo)</li>
                    <li>• Otimize para SEO para aumentar tráfego</li>
                    <li>• Monitore RPM (receita por mil impressões) no AdSense</li>
                    <li>• Fichas técnicas de carros populares geram mais cliques</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Botão de Salvar */}
        <div className="mt-8 flex justify-end gap-4">
          <Button variant="outline">Cancelar</Button>
          <Button onClick={handleSaveSettings} disabled={isSaving} className="bg-blue-600 hover:bg-blue-700">
            {isSaving ? "Salvando..." : "Salvar Todas as Configurações"}
          </Button>
        </div>
      </div>
    </div>
  );
}
