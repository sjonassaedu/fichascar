# 🚀 Guia de Deploy Profissional - FichasCAR no Digital Ocean

Este guia foi refatorado para garantir um deploy limpo, seguro e eficiente do seu projeto **FichasCAR** no Digital Ocean, seguindo as melhores práticas de engenharia de software.

## 📋 Pré-requisitos

- **Droplet Digital Ocean:** Um servidor Linux (Ubuntu 22.04 LTS recomendado).
- **Acesso SSH:** Chave SSH configurada para acesso `root` ou um usuário `sudo`.
- **Domínio:** Seu domínio configurado para apontar para o IP do Droplet.
- **Chaves de API:** Suas chaves para Gemini e Manus (se aplicável).

## 🎯 Passo 1: Conectar e Preparar o Ambiente

Conecte-se ao seu Droplet via SSH.

```bash
# Exemplo:
ssh root@SEU_IP_DO_DROPLET
```

### 1.1 Instalar Dependências do Sistema

Instale as ferramentas essenciais: Node.js (versão 22 LTS), Git, pnpm, PM2, Nginx e MySQL.

```bash
# Atualizar o sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js 22 LTS
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs git

# Instalar pnpm (gerenciador de pacotes)
sudo npm install -g pnpm

# Instalar PM2 (gerenciador de processos para produção)
sudo npm install -g pm2

# Instalar Nginx (servidor web e proxy reverso)
sudo apt install -y nginx

# Instalar MySQL Server (banco de dados)
sudo apt install -y mysql-server

# Habilitar serviços
sudo systemctl start nginx
sudo systemctl enable nginx
sudo systemctl start mysql
sudo systemctl enable mysql
```

## 🎯 Passo 2: Clonar o Repositório e Configurar o Projeto

### 2.1 Clonar o Código

Recomendamos clonar o projeto em um diretório de usuário não-root para maior segurança, mas para simplificar o guia, usaremos `/var/www/`.

```bash
# Criar diretório de projeto e navegar
sudo mkdir -p /var/www/fichascar
sudo chown -R $USER:$USER /var/www/fichascar
cd /var/www/fichascar

# Clonar o repositório
git clone https://github.com/sjonassaedu/fichascar.git .
```

### 2.2 Configurar Variáveis de Ambiente

Crie o arquivo `.env` a partir do `.env.example` e preencha com suas chaves e senhas.

```bash
cp .env.example .env
# Edite o arquivo .env com suas informações
nano .env
```

**Variáveis Chave:**

| Variável | Descrição | Valor de Exemplo |
| :--- | :--- | :--- |
| `DATABASE_URL` | String de conexão do MySQL. | `mysql://fichas_user:fichas_senha_123@localhost:3306/fichas_ai_db` |
| `JWT_SECRET` | Chave secreta para JWT (mín. 32 caracteres). | `sua-chave-secreta-super-segura-aqui-min-32-caracteres` |
| `GEMINI_API_KEY` | Sua chave de API do Google Gemini. | `AIzaSy...` |

### 2.3 Instalar Dependências e Fazer Build

Instale as dependências e compile o projeto para produção.

```bash
# Instalar dependências
pnpm install

# Fazer o build (compila frontend e backend)
pnpm build
```

## 🎯 Passo 3: Configurar o Banco de Dados MySQL

Crie o banco de dados e o usuário dedicado para a aplicação.

```bash
# Configuração do MySQL
sudo mysql -u root << 'MYSQL_SETUP'
# Crie o banco de dados
CREATE DATABASE IF NOT EXISTS fichas_ai_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Crie o usuário e defina a senha (use a mesma do seu .env)
CREATE USER IF NOT EXISTS 'fichas_user'@'localhost' IDENTIFIED BY 'fichas_senha_123';

# Conceda permissões
GRANT ALL PRIVILEGES ON fichas_ai_db.* TO 'fichas_user'@'localhost';
FLUSH PRIVILEGES;
MYSQL_SETUP

# Aplicar as migrações do Drizzle ORM
pnpm db:push
```

## 🎯 Passo 4: Iniciar a Aplicação com PM2

Use o PM2 para iniciar e gerenciar o processo do servidor em produção.

```bash
cd /var/www/fichascar
# Iniciar a aplicação usando o arquivo de configuração ecosystem.config.js
pm2 start ecosystem.config.js

# Configurar o PM2 para iniciar automaticamente no boot do sistema
pm2 save
pm2 startup

# Verificar o status
pm2 status
```

## 🎯 Passo 5: Configurar Nginx como Proxy Reverso

Configure o Nginx para rotear o tráfego da porta 80 (HTTP) para a porta 3000 (onde o PM2 está rodando o servidor Node.js).

```bash
# Substitua SEU_DOMINIO.COM.BR e SEU_IP_DO_DROPLET
NGINX_CONF="
server {
    listen 80;
    server_name SEU_DOMINIO.COM.BR www.SEU_DOMINIO.COM.BR SEU_IP_DO_DROPLET;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
"

# Salvar a configuração do Nginx
echo "$NGINX_CONF" | sudo tee /etc/nginx/sites-available/fichascar.conf

# Ativar a configuração e remover o default
sudo ln -sf /etc/nginx/sites-available/fichascar.conf /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Testar e reiniciar o Nginx
sudo nginx -t
sudo systemctl restart nginx
```

## 🎯 Passo 6: Configurar SSL com Certbot (Opcional, mas Recomendado)

Após o domínio propagar, configure o SSL para usar HTTPS.

```bash
# Instalar Certbot (se não o fez no Passo 1)
sudo apt install -y certbot python3-certbot-nginx

# Rodar o Certbot. Ele detectará a configuração do Nginx e fará o resto.
sudo certbot --nginx -d SEU_DOMINIO.COM.BR -d www.SEU_DOMINIO.COM.BR
```

## 📝 Atualização Contínua (Fluxo de Trabalho)

Sempre que você fizer mudanças no seu repositório GitHub e quiser atualizar o servidor:

```bash
cd /var/www/fichascar
git pull origin main # Ou a branch que você estiver usando
pnpm install
pnpm build
pm2 restart fichas-ai
```

## ✅ Checklist de Sucesso

- [ ] Dependências do sistema instaladas (Node.js, Git, pnpm, PM2, Nginx, MySQL).
- [ ] Repositório clonado em `/var/www/fichascar`.
- [ ] Arquivo `.env` criado e preenchido.
- [ ] `pnpm install` e `pnpm build` executados com sucesso.
- [ ] Banco de dados criado e migrações aplicadas (`pnpm db:push`).
- [ ] Aplicação iniciada com PM2 (`pm2 status` mostra `online`).
- [ ] Nginx configurado como proxy reverso.
- [ ] Site acessível via IP ou domínio.
- [ ] SSL configurado (HTTPS).

---
**Fim do Guia.** Seu projeto está agora refatorado e pronto para o deploy profissional.
