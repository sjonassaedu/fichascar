# 🚀 Deploy via GitHub - FichasCAR no Digital Ocean

Guia completo para fazer deploy do seu repositório GitHub no Digital Ocean em 10 minutos.

## 📋 Pré-requisitos

- ✅ Repositório GitHub: https://github.com/sjonassaedu/fichascar/
- ✅ IP do Droplet: `143.244.185.68`
- ✅ Chave SSH: `digitaloceanfichascar`
- ✅ Passphrase: `Camilo28@`

## 🎯 Passo 1: Conectar ao Droplet via SSH

No seu computador:

```bash
ssh -i digitaloceanfichascar root@143.244.185.68
# Digite a passphrase: Camilo28@
```

Agora você está dentro do servidor.

## 🎯 Passo 2: Instalar Dependências do Sistema

Cole estes comandos **um por um**:

### 2.1 Atualizar sistema
```bash
apt update && apt upgrade -y
```

### 2.2 Instalar Node.js 22
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs npm
node --version
npm --version
```

### 2.3 Instalar Git
```bash
apt install -y git
git --version
```

### 2.4 Instalar pnpm
```bash
npm install -g pnpm
pnpm --version
```

### 2.5 Instalar PM2
```bash
npm install -g pm2
pm2 --version
```

### 2.6 Instalar Nginx
```bash
apt install -y nginx
systemctl start nginx
systemctl enable nginx
```

### 2.7 Instalar MySQL
```bash
apt install -y mysql-server
systemctl start mysql
systemctl enable mysql
```

### 2.8 Instalar Certbot (para SSL)
```bash
apt install -y certbot python3-certbot-nginx
```

## 🎯 Passo 3: Clonar Repositório GitHub

```bash
cd /root
git clone https://github.com/sjonassaedu/fichascar.git
cd fichascar
ls -la
```

Você deve ver: `client/`, `server/`, `drizzle/`, `package.json`, `pnpm-lock.yaml`, etc.

## 🎯 Passo 4: Instalar Dependências do Projeto

```bash
pnpm install
```

Aguarde 2-3 minutos enquanto as dependências são instaladas.

## 🎯 Passo 5: Fazer Build do Projeto

```bash
pnpm build
```

Aguarde 1-2 minutos. Você deve ver:

```
✓ built in X.XXs
```

## 🎯 Passo 6: Configurar Banco de Dados MySQL

### 6.1 Criar banco de dados
```bash
mysql -u root << 'MYSQL_SETUP'
CREATE DATABASE IF NOT EXISTS fichas_ai_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'fichas_user'@'localhost' IDENTIFIED BY 'fichas_senha_123';
GRANT ALL PRIVILEGES ON fichas_ai_db.* TO 'fichas_user'@'localhost';
FLUSH PRIVILEGES;
MYSQL_SETUP
```

### 6.2 Testar conexão
```bash
mysql -u fichas_user -p fichas_ai_db
# Digite a senha: fichas_senha_123
# Se conectar, digite: EXIT;
```

## 🎯 Passo 7: Criar Arquivo .env

```bash
cat > /root/fichascar/.env << 'EOF'
# Banco de Dados
DATABASE_URL=mysql://fichas_user:fichas_senha_123@localhost:3306/fichas_ai_db

# Autenticação
JWT_SECRET=sua-chave-secreta-super-segura-aqui-min-32-caracteres

# Aplicação
VITE_APP_TITLE=FichasCAR
VITE_APP_LOGO=/logo.png
NODE_ENV=production
PORT=3000

# IA - Gemini
GEMINI_API_KEY=AIzaSyA8u0yeY_Gi5z8Vumd4YqzeXb-zrBYtw0I

# Manus (opcional)
VITE_APP_ID=seu-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
OWNER_OPEN_ID=seu-owner-id
OWNER_NAME=Jonas Saraiva Santos
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua-chave-manus
VITE_FRONTEND_FORGE_API_KEY=sua-chave-frontend-manus
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_ANALYTICS_ENDPOINT=https://analytics.manus.im
VITE_ANALYTICS_WEBSITE_ID=seu-website-id
EOF
```

### 7.1 Verificar arquivo
```bash
cat /root/fichascar/.env
```

## 🎯 Passo 8: Iniciar Aplicação com PM2

```bash
cd /root/fichascar
pm2 start ecosystem.config.js
pm2 save
pm2 startup
pm2 status
```

Você deve ver a aplicação `fichas-ai` com status `online`.

### 8.1 Ver logs
```bash
pm2 logs fichas-ai --lines 20
```

## 🎯 Passo 9: Configurar Nginx como Reverse Proxy

```bash
cat > /etc/nginx/sites-available/fichascar.com.br << 'NGINX_CONF'
server {
    listen 80;
    server_name fichascar.com.br www.fichascar.com.br 143.244.185.68;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
NGINX_CONF
```

### 9.1 Ativar configuração
```bash
ln -sf /etc/nginx/sites-available/fichascar.com.br /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx
```

## 🎯 Passo 10: Testar Site

Abra seu navegador e acesse:

```
http://143.244.185.68
```

Você deve ver a página inicial do FichasCAR! 🎉

### 10.1 Testar Admin
```
http://143.244.185.68/admin/settings
```

## 🎯 Passo 11: Apontar Domínio (Opcional)

Se quiser usar `fichascar.com.br`:

1. Vá ao seu registrador de domínio
2. Altere os DNS para apontar para: `143.244.185.68`
3. Aguarde 24-48 horas
4. Acesse: `http://fichascar.com.br`

## 🎯 Passo 12: Configurar SSL com Certbot (Opcional)

Após apontar o domínio:

```bash
certbot certonly --standalone -d fichascar.com.br -d www.fichascar.com.br
```

Siga as instruções na tela.

## 📝 Atualizar Código do GitHub

Sempre que você fizer mudanças no GitHub e quiser atualizar o servidor:

```bash
cd /root/fichascar
git pull origin main
pnpm install
pnpm build
pm2 restart fichas-ai
```

## 📊 Comandos Úteis

```bash
# Status da aplicação
pm2 status

# Ver logs em tempo real
pm2 logs fichas-ai

# Reiniciar aplicação
pm2 restart fichas-ai

# Parar aplicação
pm2 stop fichas-ai

# Iniciar aplicação
pm2 start fichas-ai

# Deletar aplicação
pm2 delete fichas-ai

# Espaço em disco
df -h

# Uso de memória
free -h

# Processos
top

# Sair do servidor
exit
```

## 🆘 Troubleshooting

### Site não carrega
```bash
pm2 status
pm2 logs fichas-ai
pm2 restart fichas-ai
```

### Erro de conexão com banco
```bash
systemctl status mysql
mysql -u fichas_user -p fichas_ai_db
cat /root/fichascar/.env | grep DATABASE_URL
```

### Porta 3000 em uso
```bash
lsof -i :3000
kill -9 PID
pm2 restart fichas-ai
```

### Nginx não inicia
```bash
nginx -t
systemctl status nginx
```

## ✅ Checklist

- [ ] SSH conectado
- [ ] Dependências do sistema instaladas
- [ ] Repositório clonado
- [ ] Dependências do projeto instaladas
- [ ] Build feito
- [ ] Banco de dados criado
- [ ] Arquivo .env criado
- [ ] Aplicação iniciada com PM2
- [ ] Nginx configurado
- [ ] Site acessível em http://143.244.185.68
- [ ] Admin acessível em http://143.244.185.68/admin/settings

## 🎉 Pronto!

Seu site FichasCAR está online via GitHub! 🚀

Agora você pode:
1. Fazer mudanças no código
2. Fazer push para GitHub
3. Executar `git pull && pnpm build && pm2 restart fichas-ai` no servidor
4. Seu site atualiza automaticamente!

---

**Sucesso! 💰**
