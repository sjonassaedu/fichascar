import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Configurações do plugin Fichas AI
 * Armazena as configurações de integração com APIs de IA
 */
export const fichasAIConfig = mysqlTable("fichas_ai_config", {
  id: int("id").autoincrement().primaryKey(),
  // Tipo de API de IA: gemini, gpt, claude, etc
  aiProvider: varchar("aiProvider", { length: 50 }).notNull().default("gemini"),
  // Chave de API (criptografada no banco)
  apiKey: text("apiKey").notNull(),
  // Prompt customizado que o usuário deseja usar
  customPrompt: text("customPrompt").notNull(),
  // Status da configuração
  isActive: boolean("isActive").notNull().default(true),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FichasAIConfig = typeof fichasAIConfig.$inferSelect;
export type InsertFichasAIConfig = typeof fichasAIConfig.$inferInsert;

/**
 * Histórico de fichas geradas
 * Armazena as fichas que foram geradas para referência e auditoria
 */
export const fichasAIHistory = mysqlTable("fichas_ai_history", {
  id: int("id").autoincrement().primaryKey(),
  // Referência ao usuário que gerou a ficha
  userId: int("userId").notNull(),
  // Dados de entrada
  marca: varchar("marca", { length: 100 }).notNull(),
  modelo: varchar("modelo", { length: 100 }).notNull(),
  ano: int("ano").notNull(),
  versao: varchar("versao", { length: 100 }).notNull(),
  // ID do post criado
  postId: int("postId"),
  // Slug do post
  slug: varchar("slug", { length: 255 }),
  // Dados da ficha gerada (JSON)
  fichaData: text("fichaData").notNull(),
  // Status da geração
  status: mysqlEnum("status", ["pendente", "sucesso", "erro"]).notNull().default("pendente"),
  // Mensagem de erro (se houver)
  errorMessage: text("errorMessage"),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FichasAIHistory = typeof fichasAIHistory.$inferSelect;
export type InsertFichasAIHistory = typeof fichasAIHistory.$inferInsert;

/**
 * Posts/Fichas públicas
 * Armazena as fichas que foram publicadas no site
 */
export const posts = mysqlTable("posts", {
  id: int("id").autoincrement().primaryKey(),
  // Informações básicas
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).unique().notNull(),
  content: text("content"),
  excerpt: varchar("excerpt", { length: 500 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  // Dados do veículo
  marca: varchar("marca", { length: 100 }).notNull(),
  modelo: varchar("modelo", { length: 100 }).notNull(),
  ano: int("ano").notNull(),
  versao: varchar("versao", { length: 100 }).notNull(),
  // Status
  published: boolean("published").default(false).notNull(),
  authorId: int("authorId").notNull(),
  fichaHistoryId: int("fichaHistoryId"),
  // ⚙️ MOTORIZAÇÃO
  motor: varchar("motor", { length: 255 }),
  tipo: varchar("tipo", { length: 100 }),
  cilindradas: varchar("cilindradas", { length: 100 }),
  cilindros: varchar("cilindros", { length: 50 }),
  valvulas: varchar("valvulas", { length: 50 }),
  potencia: varchar("potencia", { length: 100 }),
  torque: varchar("torque", { length: 100 }),
  combustivel: varchar("combustivel", { length: 100 }),
  transmissao: varchar("transmissao", { length: 100 }),
  cambio: varchar("cambio", { length: 100 }),
  // 🏁 DESEMPENHO
  velocidadeMaxima: varchar("velocidadeMaxima", { length: 100 }),
  aceleracao0100: varchar("aceleracao0100", { length: 100 }),
  aceleracao060: varchar("aceleracao060", { length: 100 }),
  aceleracao080: varchar("aceleracao080", { length: 100 }),
  consumoUrbano: varchar("consumoUrbano", { length: 100 }),
  consumoRodoviario: varchar("consumoRodoviario", { length: 100 }),
  consumoCombinado: varchar("consumoCombinado", { length: 100 }),
  emissaoCO2: varchar("emissaoCO2", { length: 100 }),
  // 📐 DIMENSÕES
  comprimento: varchar("comprimento", { length: 100 }),
  largura: varchar("largura", { length: 100 }),
  altura: varchar("altura", { length: 100 }),
  entreEixos: varchar("entreEixos", { length: 100 }),
  peso: varchar("peso", { length: 100 }),
  pesoVazio: varchar("pesoVazio", { length: 100 }),
  portaMalas: varchar("portaMalas", { length: 100 }),
  tanque: varchar("tanque", { length: 100 }),
  raioGiro: varchar("raioGiro", { length: 100 }),
  // 📏 DIMENSÕES INTERNAS
  comprimentoInterno: varchar("comprimentoInterno", { length: 100 }),
  larguraInterno: varchar("larguraInterno", { length: 100 }),
  alturaInterno: varchar("alturaInterno", { length: 100 }),
  espacoCarga: varchar("espacoCarga", { length: 100 }),
  // 🔧 MECÂNICA E CHASSIS
  direcao: varchar("direcao", { length: 100 }),
  direcaoTipo: varchar("direcaoTipo", { length: 100 }),
  tracao: varchar("tracao", { length: 100 }),
  suspensaoDianteira: varchar("suspensaoDianteira", { length: 100 }),
  suspensaoDianteiraDetalhes: varchar("suspensaoDianteiraDetalhes", { length: 255 }),
  suspensaoTraseira: varchar("suspensaoTraseira", { length: 100 }),
  suspensaoTraseiraDetalhes: varchar("suspensaoTraseiraDetalhes", { length: 255 }),
  freioDianteiro: varchar("freioDianteiro", { length: 100 }),
  freioTraseiro: varchar("freioTraseiro", { length: 100 }),
  sistemaFreios: varchar("sistemaFreios", { length: 100 }),
  rodas: varchar("rodas", { length: 100 }),
  pneus: varchar("pneus", { length: 100 }),
  // 👥 CAPACIDADES
  portas: varchar("portas", { length: 50 }),
  lugares: varchar("lugares", { length: 50 }),
  capacidadePassageiros: varchar("capacidadePassageiros", { length: 50 }),
  // 🎨 EXTRAS
  tipoCarroceria: varchar("tipoCarroceria", { length: 100 }),
  acabamento: varchar("acabamento", { length: 100 }),
  pintura: varchar("pintura", { length: 100 }),
  equipamentosSeguranca: text("equipamentosSeguranca"),
  equipamentosConforto: text("equipamentosConforto"),
  // SEO
  metaDescription: varchar("metaDescription", { length: 160 }),
  metaKeywords: varchar("metaKeywords", { length: 255 }),
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Post = typeof posts.$inferSelect;
export type InsertPost = typeof posts.$inferInsert;

/**
 * Comentários em fichas
 * Armazena comentários de usuários nas fichas
 */
export const comments = mysqlTable("comments", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  rating: int("rating"), // 1-5 stars
  approved: boolean("approved").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;

/**
 * Comparações de veículos
 * Armazena comparações salvas pelos usuários
 */
export const comparisons = mysqlTable("comparisons", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  post1Id: int("post1Id").notNull(),
  post2Id: int("post2Id"),
  post3Id: int("post3Id"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Comparison = typeof comparisons.$inferSelect;
export type InsertComparison = typeof comparisons.$inferInsert;
