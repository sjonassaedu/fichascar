# ⚡ Quick Start - Deploy via GitHub (10 minutos)

## 🚀 Resumo Rápido

1. **SSH no servidor**: `ssh -i digitaloceanfichascar root@143.244.185.68`
2. **Clonar repo**: `git clone https://github.com/sjonassaedu/fichascar.git && cd fichascar`
3. **Instalar**: `pnpm install && pnpm build`
4. **Configurar**: Criar `.env` com variáveis
5. **Rodar**: `pm2 start ecosystem.config.js`
6. **Acessar**: `http://143.244.185.68`

## 📋 Comandos Completos (Copie e Cole)

```bash
# 1. Conectar
ssh -i digitaloceanfichascar root@143.244.185.68

# 2. Instalar dependências do sistema
apt update && apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs npm git nginx mysql-server certbot python3-certbot-nginx
npm install -g pnpm pm2

# 3. Clonar repositório
cd /root
git clone https://github.com/sjonassaedu/fichascar.git
cd fichascar

# 4. Instalar dependências do projeto
pnpm install

# 5. Fazer build
pnpm build

# 6. Configurar banco de dados
mysql -u root << 'MYSQL'
CREATE DATABASE fichas_ai_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'fichas_user'@'localhost' IDENTIFIED BY 'fichas_senha_123';
GRANT ALL PRIVILEGES ON fichas_ai_db.* TO 'fichas_user'@'localhost';
FLUSH PRIVILEGES;
MYSQL

# 7. Criar arquivo .env
cat > .env << 'ENV'
DATABASE_URL=mysql://fichas_user:fichas_senha_123@localhost:3306/fichas_ai_db
JWT_SECRET=sua-chave-secreta-super-segura-aqui-min-32-caracteres
VITE_APP_TITLE=FichasCAR
VITE_APP_LOGO=/logo.png
NODE_ENV=production
PORT=3000
GEMINI_API_KEY=AIzaSyA8u0yeY_Gi5z8Vumd4YqzeXb-zrBYtw0I
ENV

# 8. Iniciar aplicação
pm2 start ecosystem.config.js
pm2 save
pm2 startup
pm2 status

# 9. Configurar Nginx
cat > /etc/nginx/sites-available/fichascar.com.br << 'NGINX'
server {
    listen 80;
    server_name fichascar.com.br www.fichascar.com.br 143.244.185.68;
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
NGINX

ln -sf /etc/nginx/sites-available/fichascar.com.br /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# 10. Sair
exit
```

## ✅ Pronto!

Acesse: **http://143.244.185.68** 🎉

---

Para guia completo, veja: **DEPLOY_GITHUB_DO.md**
