export const COOKIE_NAME = "fichascar_session";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;

export const UNAUTHED_ERR_MSG = "UNAUTHORIZED";
