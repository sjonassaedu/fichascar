import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getFichasAIConfig, updateFichasAIConfig, saveFichaHistory, updateFichaHistoryStatus, getFichaHistory, getUserFichaHistory, createPost, getPostBySlug, getPublishedPosts, getAllPosts, createComment, getPostComments, createComparison, getUserComparisons, getComparisonById } from "./db";
import { invokeLLM } from "./_core/llm";

// Helper para gerar slug
function generateSlug(marca: string, modelo: string, ano: number, versao: string): string {
  return `${marca}-${modelo}-${versao}-${ano}`.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * Fichas AI Router
   * Gerencia configurações e geração de fichas técnicas de veículos
   */
  fichasAI: router({
    // Obter configuração atual
    getConfig: publicProcedure.query(async () => {
      return await getFichasAIConfig();
    }),

    // Atualizar configuração
    updateConfig: protectedProcedure
      .input(
        z.object({
          aiProvider: z.enum(["gemini", "gpt", "claude"]).optional(),
          apiKey: z.string().min(1).optional(),
          customPrompt: z.string().min(10).optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Apenas admin pode atualizar configurações
        if (ctx.user?.role !== "admin") {
          throw new Error("Acesso negado. Apenas administradores podem atualizar configurações.");
        }

        await updateFichasAIConfig({
          aiProvider: input.aiProvider,
          apiKey: input.apiKey,
          customPrompt: input.customPrompt,
          isActive: input.isActive,
        });

        return { success: true };
      }),

    // Gerar ficha técnica
    generateFicha: protectedProcedure
      .input(
        z.object({
          marca: z.string().min(1),
          modelo: z.string().min(1),
          ano: z.number().int().min(1900).max(new Date().getFullYear() + 1),
          versao: z.string().min(1),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user?.id) {
          throw new Error("Usuário não autenticado");
        }

        // Obter configuração
        const config = await getFichasAIConfig();
        if (!config || !config.isActive) {
          throw new Error("Fichas AI não está configurado ou desativado");
        }

        // Salvar no histórico com status pendente
        const history = await saveFichaHistory({
          userId: ctx.user.id,
          marca: input.marca,
          modelo: input.modelo,
          ano: input.ano,
          versao: input.versao,
          fichaData: "{}",
          status: "pendente",
          postId: null,
          slug: null,
          errorMessage: null,
        });

        try {
          // Preparar prompt
          const prompt = config.customPrompt
            .replace("{marca}", input.marca)
            .replace("{modelo}", input.modelo)
            .replace("{ano}", input.ano.toString())
            .replace("{versao}", input.versao);

          // Chamar LLM com schema JSON estruturado
          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content:
                  "Você é um especialista em veículos. Retorne sempre um JSON válido com os dados técnicos do veículo.",
              },
              {
                role: "user",
                content: prompt,
              },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "vehicle_specs",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    motor: { type: "string" },
                    tipo: { type: "string" },
                    cilindradas: { type: "string" },
                    potencia: { type: "string" },
                    torque: { type: "string" },
                    combustivel: { type: "string" },
                    transmissao: { type: "string" },
                    velocidadeMaxima: { type: "string" },
                    aceleracao: { type: "string" },
                    consumoUrbano: { type: "string" },
                    consumoRodoviario: { type: "string" },
                    comprimento: { type: "string" },
                    largura: { type: "string" },
                    altura: { type: "string" },
                    entreEixos: { type: "string" },
                    peso: { type: "string" },
                    portaMalas: { type: "string" },
                    tanque: { type: "string" },
                    direcao: { type: "string" },
                    tracao: { type: "string" },
                    suspensaoDianteira: { type: "string" },
                    suspensaoTraseira: { type: "string" },
                    freioDianteiro: { type: "string" },
                    freioTraseiro: { type: "string" },
                    rodas: { type: "string" },
                    pneus: { type: "string" },
                    portas: { type: "string" },
                    lugares: { type: "string" },
                  },
                  required: [
                    "motor",
                    "tipo",
                    "cilindradas",
                    "potencia",
                    "torque",
                    "combustivel",
                    "transmissao",
                    "velocidadeMaxima",
                    "aceleracao",
                    "consumoUrbano",
                    "consumoRodoviario",
                    "comprimento",
                    "largura",
                    "altura",
                    "entreEixos",
                    "peso",
                    "portaMalas",
                    "tanque",
                    "direcao",
                    "tracao",
                    "suspensaoDianteira",
                    "suspensaoTraseira",
                    "freioDianteiro",
                    "freioTraseiro",
                    "rodas",
                    "pneus",
                    "portas",
                    "lugares",
                  ],
                  additionalProperties: false,
                },
              },
            },
          });

          // Extrair conteúdo JSON
          const content = response.choices[0].message.content;
          if (!content || typeof content !== 'string') {
            throw new Error("Resposta vazia da IA");
          }

          const fichaData = JSON.parse(content);

          // Gerar slug para o post
          const slug = generateSlug(input.marca, input.modelo, input.ano, input.versao);

          // Criar post no banco de dados
          const post = await createPost({
            title: `${input.marca} ${input.modelo} ${input.versao} (${input.ano})`,
            slug: slug,
            excerpt: `Ficha técnica completa do ${input.marca} ${input.modelo} ${input.ano}`,
            content: JSON.stringify(fichaData),
            marca: input.marca,
            modelo: input.modelo,
            ano: input.ano,
            versao: input.versao,
            published: true,
            authorId: ctx.user.id,
            fichaHistoryId: history.id,
            // Preencher todos os campos da ficha
            motor: fichaData.motor || null,
            tipo: fichaData.tipo || null,
            cilindradas: fichaData.cilindradas || null,
            cilindros: fichaData.cilindros || null,
            valvulas: fichaData.valvulas || null,
            potencia: fichaData.potencia || null,
            torque: fichaData.torque || null,
            combustivel: fichaData.combustivel || null,
            transmissao: fichaData.transmissao || null,
            cambio: fichaData.cambio || null,
            velocidadeMaxima: fichaData.velocidadeMaxima || null,
            aceleracao0100: fichaData.aceleracao0100 || null,
            consumoUrbano: fichaData.consumoUrbano || null,
            consumoRodoviario: fichaData.consumoRodoviario || null,
            consumoCombinado: fichaData.consumoCombinado || null,
            emissaoCO2: fichaData.emissaoCO2 || null,
            comprimento: fichaData.comprimento || null,
            largura: fichaData.largura || null,
            altura: fichaData.altura || null,
            entreEixos: fichaData.entreEixos || null,
            peso: fichaData.peso || null,
            portaMalas: fichaData.portaMalas || null,
            tanque: fichaData.tanque || null,
            direcao: fichaData.direcao || null,
            tracao: fichaData.tracao || null,
            suspensaoDianteira: fichaData.suspensaoDianteira || null,
            suspensaoTraseira: fichaData.suspensaoTraseira || null,
            freioDianteiro: fichaData.freioDianteiro || null,
            freioTraseiro: fichaData.freioTraseiro || null,
            rodas: fichaData.rodas || null,
            pneus: fichaData.pneus || null,
            portas: fichaData.portas || null,
            lugares: fichaData.lugares || null,
            metaDescription: `Ficha técnica do ${input.marca} ${input.modelo} ${input.ano} - Dados técnicos completos`,
            metaKeywords: `${input.marca}, ${input.modelo}, ${input.ano}, ficha técnica`,
          });

          // Atualizar histórico com sucesso
          await updateFichaHistoryStatus(history.id, "sucesso", fichaData);

          return {
            success: true,
            historyId: history.id,
            postId: post.id,
            slug: post.slug,
            ficha: fichaData,
          };
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : "Erro desconhecido";
          await updateFichaHistoryStatus(history.id, "erro", errorMessage);

          throw new Error(`Erro ao gerar ficha: ${errorMessage}`);
        }
      }),

    // Obter histórico de fichas do usuário
    getHistory: protectedProcedure.query(async ({ ctx }) => {
      if (!ctx.user?.id) {
        throw new Error("Usuário não autenticado");
      }

      return await getUserFichaHistory(ctx.user.id);
    }),

    // Obter ficha específica
    getFicha: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const ficha = await getFichaHistory(input.id);

        if (!ficha) {
          throw new Error("Ficha não encontrada");
        }

        // Verificar se o usuário é o dono ou admin
        if (ficha.userId !== ctx.user?.id && ctx.user?.role !== "admin") {
          throw new Error("Acesso negado");
        }

        return ficha;
      }),
  }),

  posts: router({
    getPublished: publicProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return await getPublishedPosts(input.limit, input.offset);
      }),
    
    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return await getPostBySlug(input.slug);
      }),
    
    getAll: protectedProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') throw new Error('Unauthorized');
        return await getAllPosts(input.limit, input.offset);
      }),
  }),

  comments: router({
    create: protectedProcedure
      .input(z.object({
        postId: z.number(),
        content: z.string().min(1).max(5000),
        rating: z.number().min(1).max(5).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await createComment({
          postId: input.postId,
          userId: ctx.user.id,
          content: input.content,
          rating: input.rating || null,
          approved: true,
        });
      }),
    
    getByPost: publicProcedure
      .input(z.object({ postId: z.number() }))
      .query(async ({ input }) => {
        return await getPostComments(input.postId);
      }),
  }),

  comparisons: router({
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1).max(255),
        post1Id: z.number(),
        post2Id: z.number().optional(),
        post3Id: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await createComparison({
          userId: ctx.user.id,
          title: input.title,
          post1Id: input.post1Id,
          post2Id: input.post2Id || null,
          post3Id: input.post3Id || null,
        });
      }),
    
    getByUser: protectedProcedure
      .query(async ({ ctx }) => {
        return await getUserComparisons(ctx.user.id);
      }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getComparisonById(input.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
