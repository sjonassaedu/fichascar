import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Search, Calendar, User } from "lucide-react";

interface FichaPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  marca: string;
  modelo: string;
  ano: number;
  imageUrl?: string;
  createdAt: string;
  published: boolean;
}

export default function Blog() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [fichas] = useState<FichaPost[]>([
    {
      id: 1,
      title: "Toyota Yaris Versão 1 (2020)",
      slug: "toyota-yaris-versao-1-2020",
      excerpt: "Ficha técnica completa do Toyota Yaris 2020 com todos os dados técnicos detalhados.",
      marca: "Toyota",
      modelo: "Yaris",
      ano: 2020,
      createdAt: new Date().toISOString(),
      published: true,
    },
  ]);

  const filteredFichas = fichas.filter(
    (ficha) =>
      ficha.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ficha.marca.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ficha.modelo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">FichasCAR</h1>
            <p className="text-sm text-gray-600">Fichas técnicas de veículos</p>
          </div>
          <nav className="flex gap-6">
            <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">
              Modelos
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">
              Comparador
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">
              Sobre
            </a>
            <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">
              Contato
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4">Encontre a Ficha Técnica do Seu Veículo</h2>
          <p className="text-lg text-blue-100 mb-8">
            Acesse informações técnicas completas de milhares de veículos
          </p>

          {/* Search Bar */}
          <div className="flex gap-2">
            <Input
              placeholder="Buscar por marca, modelo ou ano..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white text-gray-900 placeholder-gray-500"
            />
            <Button className="bg-white text-blue-600 hover:bg-gray-100">
              <Search className="h-4 w-4 mr-2" />
              Buscar
            </Button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Results Info */}
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900">
            {filteredFichas.length} Ficha{filteredFichas.length !== 1 ? "s" : ""} Encontrada{filteredFichas.length !== 1 ? "s" : ""}
          </h3>
          <p className="text-gray-600">Escolha uma ficha para ver os detalhes técnicos completos</p>
        </div>

        {/* Fichas Grid */}
        {filteredFichas.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFichas.map((ficha) => (
              <Card
                key={ficha.id}
                className="hover:shadow-lg transition-shadow cursor-pointer overflow-hidden"
                onClick={() => navigate(`/ficha/${ficha.slug}`)}
              >
                {ficha.imageUrl && (
                  <div className="h-48 bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                    <img src={ficha.imageUrl} alt={ficha.title} className="w-full h-full object-cover" />
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-lg">{ficha.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-600 text-sm">{ficha.excerpt}</p>

                  <div className="flex flex-wrap gap-2">
                    <span className="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                      {ficha.marca}
                    </span>
                    <span className="bg-gray-100 text-gray-800 text-xs px-3 py-1 rounded-full">
                      {ficha.ano}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-gray-500 pt-4 border-t">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(ficha.createdAt).toLocaleDateString("pt-BR")}
                    </div>
                  </div>

                  <Button className="w-full mt-4" variant="outline">
                    Ver Ficha Completa →
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">Nenhuma ficha encontrada com os critérios de busca.</p>
            <Button
              variant="outline"
              onClick={() => setSearchTerm("")}
              className="mt-4"
            >
              Limpar Filtros
            </Button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">FichasCAR</h4>
              <p className="text-gray-400 text-sm">
                Fichas técnicas completas de veículos com dados precisos e atualizados.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">Modelos</a></li>
                <li><a href="#" className="hover:text-white">Comparador</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Sobre</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white">Sobre Nós</a></li>
                <li><a href="#" className="hover:text-white">Contato</a></li>
                <li><a href="#" className="hover:text-white">Privacidade</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contato</h4>
              <p className="text-sm text-gray-400">
                Email: contato@fichascar.com.br
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2024 FichasCAR. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
