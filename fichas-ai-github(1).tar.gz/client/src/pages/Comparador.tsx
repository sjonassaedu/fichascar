import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, X } from "lucide-react";
import { useLocation } from "wouter";

interface VehicleData {
  id: number;
  title: string;
  marca: string;
  modelo: string;
  ano: number;
  potencia: string;
  velocidadeMaxima: string;
  aceleracao0100: string;
  consumoUrbano: string;
  comprimento: string;
  peso: string;
  portas: string;
}

export default function Comparador() {
  const [, navigate] = useLocation();
  const [selectedVehicles, setSelectedVehicles] = useState<VehicleData[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  // Dados de exemplo - em produção viriam da API
  const availableVehicles: VehicleData[] = [
    {
      id: 1,
      title: "Toyota Yaris Versão 1 (2020)",
      marca: "Toyota",
      modelo: "Yaris",
      ano: 2020,
      potencia: "87 cv",
      velocidadeMaxima: "180 km/h",
      aceleracao0100: "10,5 s",
      consumoUrbano: "12,8 km/l",
      comprimento: "3.945 mm",
      peso: "1.050 kg",
      portas: "4",
    },
  ];

  const handleSelectVehicle = (vehicle: VehicleData) => {
    if (selectedVehicles.length < 3 && !selectedVehicles.find(v => v.id === vehicle.id)) {
      setSelectedVehicles([...selectedVehicles, vehicle]);
    }
  };

  const handleRemoveVehicle = (id: number) => {
    setSelectedVehicles(selectedVehicles.filter(v => v.id !== id));
  };

  const filteredVehicles = availableVehicles.filter(v =>
    v.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate("/blog")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Comparador de Veículos</h1>
          <div className="w-32"></div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Seletor de Veículos */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Selecionar Veículos</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Buscar veículos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredVehicles.map((vehicle) => (
                    <Button
                      key={vehicle.id}
                      variant={selectedVehicles.find(v => v.id === vehicle.id) ? "default" : "outline"}
                      className="w-full justify-start text-left"
                      onClick={() => handleSelectVehicle(vehicle)}
                      disabled={selectedVehicles.length >= 3 && !selectedVehicles.find(v => v.id === vehicle.id)}
                    >
                      <div className="truncate">
                        <p className="font-semibold">{vehicle.marca}</p>
                        <p className="text-xs">{vehicle.modelo} {vehicle.ano}</p>
                      </div>
                    </Button>
                  ))}
                </div>

                <p className="text-xs text-gray-500">
                  {selectedVehicles.length}/3 veículos selecionados
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Tabela Comparativa */}
          <div className="lg:col-span-3">
            {selectedVehicles.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-blue-600 text-white">
                      <th className="border p-3 text-left font-semibold">Especificação</th>
                      {selectedVehicles.map((vehicle) => (
                        <th key={vehicle.id} className="border p-3 text-center">
                          <div className="flex items-center justify-between gap-2">
                            <div className="text-sm">
                              <p className="font-semibold">{vehicle.marca}</p>
                              <p className="text-xs text-blue-100">{vehicle.modelo} {vehicle.ano}</p>
                            </div>
                            <button
                              onClick={() => handleRemoveVehicle(vehicle.id)}
                              className="text-blue-100 hover:text-white"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Potência</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.potencia}
                        </td>
                      ))}
                    </tr>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Velocidade Máxima</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.velocidadeMaxima}
                        </td>
                      ))}
                    </tr>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Aceleração 0-100</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.aceleracao0100}
                        </td>
                      ))}
                    </tr>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Consumo Urbano</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.consumoUrbano}
                        </td>
                      ))}
                    </tr>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Comprimento</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.comprimento}
                        </td>
                      ))}
                    </tr>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Peso</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.peso}
                        </td>
                      ))}
                    </tr>
                    <tr className="hover:bg-gray-100">
                      <td className="border p-3 font-semibold bg-gray-50">Portas</td>
                      {selectedVehicles.map((vehicle) => (
                        <td key={vehicle.id} className="border p-3 text-center">
                          {vehicle.portas}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-gray-600 mb-4">Selecione até 3 veículos para comparar</p>
                  <Button onClick={() => navigate("/blog")} variant="outline">
                    Voltar ao Blog
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
