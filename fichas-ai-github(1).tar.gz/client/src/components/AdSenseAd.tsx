import { useEffect } from "react";

interface AdSenseAdProps {
  slot: string;
  format?: "auto" | "horizontal" | "vertical" | "rectangle";
  responsive?: boolean;
  className?: string;
}

export default function AdSenseAd({
  slot,
  format = "auto",
  responsive = true,
  className = "",
}: AdSenseAdProps) {
  useEffect(() => {
    // Carregar script do Google AdSense se não estiver carregado
    if (typeof window !== "undefined" && !(window as any).adsbygoogle) {
      const script = document.createElement("script");
      script.async = true;
      script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-xxxxxxxxxxxxxxxx";
      script.crossOrigin = "anonymous";
      document.head.appendChild(script);
    }

    // Processar anúncios
    try {
      ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
    } catch (e) {
      console.error("Erro ao carregar AdSense:", e);
    }
  }, []);

  return (
    <div className={`adsense-container ${className}`}>
      <ins
        className="adsbygoogle"
        style={{
          display: "block",
          textAlign: "center",
          minHeight: "250px",
        }}
        data-ad-client="ca-pub-xxxxxxxxxxxxxxxx"
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive}
      />
    </div>
  );
}
